(function () {
  'use strict';

  const data = window.STARMAP;
  const $ = id => document.getElementById(id);
  const map = $('map');
  const plan = $('plan');
  const groups = new Map(data.groups.map(group => [group.id, group]));
  const activeGroups = new Set(groups.keys());
  const storageKey = 'starmap:found:' + data.id;
  const found = new Set(readProgress());
  const entries = [];
  const categoryInputs = new Map();
  let selected = null;
  let scale = 1;
  let minScale = 1;
  let maxScale = 1;
  let left = 0;
  let top = 0;
  let fitted = true;

  const points = data.points.map(point => ({
    ...point,
    px: data.origin[0] + point.x,
    py: data.origin[1] + point.y,
  }));
  const leftEdge = Math.min(data.bounds[0], ...points.map(point => point.px));
  const topEdge = Math.min(data.bounds[1], ...points.map(point => point.py));
  const rightEdge = Math.max(data.bounds[2], ...points.map(point => point.px));
  const bottomEdge = Math.max(data.bounds[3], ...points.map(point => point.py));

  function readProgress() {
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey));
      return Array.isArray(saved) ? saved.filter(id => data.points.some(point => point.id === id)) : [];
    } catch {
      return [];
    }
  }

  function symbol(group) {
    const icon = document.createElement('span');
    icon.className = 'symbol';
    icon.style.setProperty('--pin', group.color);
    icon.textContent = group.symbol;
    icon.setAttribute('aria-hidden', 'true');
    return icon;
  }

  document.querySelector('[data-source]').href = data.source;
  $('world').textContent = data.world;
  $('location').textContent = data.name;
  $('map-caption').textContent = data.name;
  $('progress').max = points.length;
  plan.style.width = data.size[0] + 'px';
  plan.style.height = data.size[1] + 'px';

  for (const group of groups.values()) {
    const label = document.createElement('label');
    label.className = 'category';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = true;
    input.addEventListener('change', () => {
      if (input.checked) activeGroups.add(group.id);
      else activeGroups.delete(group.id);
      render();
    });
    categoryInputs.set(group.id, input);
    const count = document.createElement('span');
    count.className = 'count';
    count.textContent = points.filter(point => point.group === group.id).length;
    count.setAttribute('aria-hidden', 'true');
    label.append(input, symbol(group), document.createTextNode(group.name), count);
    $('categories').append(label);
  }

  for (const point of points) {
    const group = groups.get(point.group);
    const title = point.name + ' №' + point.number;
    const pin = document.createElement('button');
    pin.type = 'button';
    pin.className = 'pin';
    pin.style.setProperty('--pin', group.color);
    pin.title = title;
    pin.setAttribute('aria-label', title);
    pin.addEventListener('click', () => openPoint(point, false));
    $('markers').append(pin);

    const item = document.createElement('li');
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'point-item';
    const index = document.createElement('span');
    index.className = 'index';
    button.append(symbol(group), document.createTextNode(point.name), index);
    button.addEventListener('click', () => openPoint(point, true));
    item.append(button);
    $('point-list').append(item);
    entries.push({point, group, pin, item, button, index});
  }

  function render() {
    const query = $('search').value.trim().toLocaleLowerCase('ru');
    const hideFound = $('hide-found').checked;
    let visible = 0;
    let selectedVisible = false;
    for (const entry of entries) {
      const {point, group, pin, item, button, index} = entry;
      const isFound = found.has(point.id);
      const matches = activeGroups.has(group.id) && (!hideFound || !isFound) &&
        (point.name + ' ' + group.name).toLocaleLowerCase('ru').includes(query);
      const isSelected = matches && selected?.id === point.id;
      if (matches) visible++;
      if (isSelected) selectedVisible = true;
      pin.hidden = item.hidden = !matches;
      pin.classList.toggle('found', isFound);
      pin.textContent = isFound ? '✓' : group.symbol;
      pin.setAttribute('aria-pressed', String(isSelected));
      button.setAttribute('aria-current', String(isSelected));
      index.textContent = (isFound ? '✓ ' : '') + '№' + point.number;
    }
    if (!selectedVisible) selected = null;
    $('visible-count').textContent = visible + ' / ' + points.length;
    $('empty').hidden = visible !== 0;
    $('progress').value = found.size;
    $('progress-text').textContent = found.size + ' / ' + points.length;
    $('toggle-filters').textContent = activeGroups.size ? 'Скрыть все' : 'Показать все';
    $('detail').hidden = !selected;
    if (selected) {
      const group = groups.get(selected.group);
      $('detail-group').textContent = group.name;
      $('detail-name').textContent = selected.name;
      $('detail-number').textContent = 'Метка №' + selected.number;
      $('mark').textContent = found.has(selected.id) ? 'Снять отметку' : 'Отметить';
      $('detail-source').href = data.source + '?zoom=0&center=' +
        selected.y.toFixed(2) + ',' + selected.x.toFixed(2) + '&shown_types=' + selected.label;
    }
  }

  function updateView() {
    const w = map.clientWidth;
    const h = map.clientHeight;
    left = Math.max(w * .2 - rightEdge * scale, Math.min(w * .8 - leftEdge * scale, left));
    top = Math.max(h * .2 - bottomEdge * scale, Math.min(h * .8 - topEdge * scale, top));
    plan.style.transform = 'translate(' + left + 'px,' + top + 'px) scale(' + scale + ')';
    for (const {point, pin} of entries) {
      pin.style.transform = 'translate(' + (left + point.px * scale) + 'px,' +
        (top + point.py * scale) + 'px)';
    }
    $('zoom-in').disabled = scale >= maxScale;
    $('zoom-out').disabled = scale <= minScale;
  }

  function fitScale() {
    return Math.min(
      map.clientWidth * .87 / (rightEdge - leftEdge),
      map.clientHeight * .85 / (bottomEdge - topEdge),
    );
  }

  function fit() {
    scale = fitScale();
    minScale = scale * .65;
    maxScale = Math.max(1.5, scale * 6);
    left = (map.clientWidth - (leftEdge + rightEdge) * scale) / 2;
    top = (map.clientHeight - (topEdge + bottomEdge) * scale) / 2;
    fitted = true;
    updateView();
  }

  function zoom(factor, x = map.clientWidth / 2, y = map.clientHeight / 2) {
    const next = Math.max(minScale, Math.min(maxScale, scale * factor));
    if (next === scale) return;
    left = x - (x - left) * next / scale;
    top = y - (y - top) * next / scale;
    scale = next;
    fitted = false;
    updateView();
  }

  function openPoint(point, center) {
    selected = point;
    if (center) {
      scale = Math.min(maxScale, Math.max(scale, fitScale() * 1.5));
      left = map.clientWidth / 2 - point.px * scale;
      top = map.clientHeight * .44 - point.py * scale;
      fitted = false;
      updateView();
    }
    render();
  }

  $('toggle-filters').addEventListener('click', () => {
    const showAll = activeGroups.size === 0;
    activeGroups.clear();
    for (const [id, input] of categoryInputs) {
      input.checked = showAll;
      if (showAll) activeGroups.add(id);
    }
    render();
  });
  $('search').addEventListener('input', render);
  $('hide-found').addEventListener('change', render);
  $('close-detail').addEventListener('click', () => {
    const previous = entries.find(entry => entry.point.id === selected?.id);
    selected = null;
    render();
    previous?.pin.focus({preventScroll:true});
  });
  $('mark').addEventListener('click', () => {
    if (!selected) return;
    const id = selected.id;
    if (found.has(id)) found.delete(id);
    else found.add(id);
    try {
      localStorage.setItem(storageKey, JSON.stringify([...found]));
    } catch {
      // The current tab still retains progress when browser storage is unavailable.
    }
    render();
    if (!selected) $('hide-found').focus();
  });
  $('zoom-in').addEventListener('click', () => zoom(1.35));
  $('zoom-out').addEventListener('click', () => zoom(1 / 1.35));
  $('fit').addEventListener('click', fit);

  map.addEventListener('wheel', event => {
    if (event.ctrlKey || event.metaKey || event.target.closest('.detail')) return;
    event.preventDefault();
    const bounds = map.getBoundingClientRect();
    zoom(event.deltaY < 0 ? 1.18 : 1 / 1.18, event.clientX - bounds.left, event.clientY - bounds.top);
  }, {passive:false});

  map.addEventListener('keydown', event => {
    if (event.key === 'Escape' && selected) {
      $('close-detail').click();
      return;
    }
    if (event.target !== map) return;
    const movement = {ArrowLeft:[55,0], ArrowRight:[-55,0], ArrowUp:[0,55], ArrowDown:[0,-55]}[event.key];
    if (movement) {
      event.preventDefault();
      left += movement[0];
      top += movement[1];
      fitted = false;
      updateView();
    } else if (event.key === '+' || event.key === '=') {
      zoom(1.35);
    } else if (event.key === '-') {
      zoom(1 / 1.35);
    } else if (event.key === '0') {
      fit();
    }
  });

  const pointers = new Map();
  map.addEventListener('pointerdown', event => {
    if (event.button !== 0 || event.target.closest('button, .detail')) return;
    pointers.set(event.pointerId, {x:event.clientX, y:event.clientY});
    map.setPointerCapture(event.pointerId);
    map.classList.add('dragging');
  });
  map.addEventListener('pointermove', event => {
    const previous = pointers.get(event.pointerId);
    if (!previous) return;
    const current = {x:event.clientX, y:event.clientY};
    const partner = [...pointers].find(([id]) => id !== event.pointerId)?.[1];
    pointers.set(event.pointerId, current);
    fitted = false;
    if (partner) {
      const bounds = map.getBoundingClientRect();
      const distance = Math.hypot(previous.x - partner.x, previous.y - partner.y);
      const nextDistance = Math.hypot(current.x - partner.x, current.y - partner.y);
      if (distance > 0 && nextDistance > 0) {
        zoom(nextDistance / distance, (previous.x + partner.x) / 2 - bounds.left,
          (previous.y + partner.y) / 2 - bounds.top);
      }
    }
    const divisor = partner ? 2 : 1;
    left += (current.x - previous.x) / divisor;
    top += (current.y - previous.y) / divisor;
    updateView();
  });
  for (const name of ['pointerup','pointercancel','lostpointercapture']) {
    map.addEventListener(name, event => {
      pointers.delete(event.pointerId);
      if (!pointers.size) map.classList.remove('dragging');
    });
  }
  new ResizeObserver(() => {
    if (fitted) fit();
    else updateView();
  }).observe(map);

  fit();
  render();
})();

